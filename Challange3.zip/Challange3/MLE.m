function [ minP, ture_X ] = MLE( P0, pts_wld, pts_img )
%MLE Summary of this function goes here
%   MLE algorithm
%% Initial value
P0_tr = P0';
p0 = P0_tr(:);
p0_8 = p0(1:8); % for Sampson error & algebraic error
p8_X0 = [p0_8;pts_wld(1,:)';pts_wld(2,:)';pts_wld(3,:)']; % for reprojection error
%% mininization process
global w
w = 1;
options = optimoptions(@lsqnonlin,'MaxFunctionEvaluations',5000,'Display','iter-detailed');
options.Algorithm = 'levenberg-marquardt';
options.StepTolerance = 1.000000e-12;
options.FunctionTolerance = 1.000000e-8;

% minp_8 = lsqnonlin(@funSamp,p0_8,[],[],options, pts_wld, pts_img);
% minP_8 = reshape(minp_8, 4, 2)';
% minP = [minP_8;0 0 0 1];
% ture_X = [];


minp_8 = lsqnonlin(@funAlge,p0_8,[],[],options, pts_wld, pts_img);
minP_8 = reshape(minp_8, 4, 2)';
minP = [minP_8;0 0 0 1];
ture_X = [];

% minp_X = lsqnonlin(@funRepro,p8_X0,[],[],options, pts_wld, pts_img);
% minp_8 = minp_X(1:8);
% minP_8 = reshape(minp_8, 4, 2)';
% minP = [minP_8;0 0 0 1];
% N = size(pts_wld,2);
% ture_X = [minp_X(9:8+N)';minp_X(9+N:8+2*N)';minp_X(9+2*N:8+3*N)';ones(1,N)];

w
end

function [ err ] = funSamp(minp_8, pts_wld, pts_img)
% This is the user-defined function to express the objective function (Sampson error)
%Arguemnt
% denote elements in h
P11 = minp_8(1);P12 = minp_8(2);P13 = minp_8(3);P14 = minp_8(4);
P21 = minp_8(5);P22 = minp_8(6);P23 = minp_8(7);P24 = minp_8(8);

P8_tmp = reshape(minp_8, 4, 2)';
P_tmp = [P8_tmp;0 0 0 1];

err_Samp = zeros(size(pts_wld,2),1);
for i = 1:size(pts_wld,2)
   eps = [pts_img(2,i)-P21*pts_wld(1,i)-P22*pts_wld(2,i)-P23*pts_wld(3,i)-P24;
          P11*pts_wld(1,i)+P12*pts_wld(2,i)+P13*pts_wld(3,i)+P14-pts_img(1,i)];
   J = [0 1 -P21 -P22 -P23;
       -1 0  P11  P12  P13];
   err_Samp(i) = sqrt(eps'*inv(J*J')*eps);
end

% minisize skew and principle points
global w
M1 = P_tmp(1,1:3)';
M2 = P_tmp(2,1:3)';
cosM1_M2 =  dot(M1,M2)/(norm(M1)*norm(M2));
cons = sqrt(w)*cosM1_M2;
w = w + 5;

%err = [err_Samp; cons];
err = err_Samp;
% display('err:');
% err'*err
end

function [err] = funRepro(minp_X, pts_wld, pts_img)
% cost function for minimize reprojection error
% build P
P8_tmp = reshape(minp_X(1:8), 4, 2)';
P_tmp = [P8_tmp;0 0 0 1];
% build X_hat
N = size(pts_wld,2);
ptsHat_wld = [minp_X(9:8+N)';minp_X(9+N:8+2*N)';minp_X(9+2*N:8+3*N)';ones(1,N)];
ptsHat_img = P_tmp*ptsHat_wld;
% make third coor 1
coor_thd = repmat(ptsHat_img(3,:),3,1);
ptsHat_img = ptsHat_img./coor_thd;

% distance between x and x_hat
dis_diff_img = pts_img - ptsHat_img;
err_img = sqrt(dis_diff_img(1,:).^2 + dis_diff_img(2,:).^2);

% distance between X and X_hat
dis_diff_wld = pts_wld - ptsHat_wld;
err_wld = sqrt(dis_diff_wld(1,:).^2 + dis_diff_wld(2,:).^2 + dis_diff_wld(3,:).^2);


% minisize skew and principle points
global w
M1 = P_tmp(1,1:3)';
M2 = P_tmp(2,1:3)';
cosM1_M2 =  dot(M1,M2)/(norm(M1)*norm(M2));
cons = sqrt(w)*cosM1_M2;
w = w + 5;
err = [err_img'; err_wld'; cons];
%err = [err_img'; err_wld'];
end

function [err] = funAlge(minp_8, pts_wld, pts_img)
% algebraic error
% if homogeneous coor of both point set is 1
% algebraic error = geometric error
P8_tmp = reshape(minp_8, 4, 2)';
P_tmp = [P8_tmp;0 0 0 1];

% transform 3D points to image plane
ptsBar_img = P_tmp*pts_wld;
coor_thd = repmat(ptsBar_img(3,:),3,1);
ptsBar_img = ptsBar_img./coor_thd;

% geometric distance
dis_diff = pts_img - ptsBar_img;
err_dis = sqrt(dis_diff(1,:).^2 + dis_diff(2,:).^2);

% minisize skew and principle points
global w
M1 = P_tmp(1,1:3)';
M2 = P_tmp(2,1:3)';
cosM1_M2 =  dot(M1,M2)/(norm(M1)*norm(M2));
cons = sqrt(w)*cosM1_M2;
err = [err_dis'; cons];
w = w + 5;
end