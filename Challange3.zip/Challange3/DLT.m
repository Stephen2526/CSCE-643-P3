function [P0] = DLT(pts_wld, pts_img)
%DLT Summary of this function goes here
%   DLT algorithm

% if size(arrS,2) < 4
%     error('points is not enough');
% end
%construct A matrix
A = zeros(2*size(pts_wld,2),8);
b = zeros(2*size(pts_wld,2),1);
for i = 1:size(pts_wld,2)
    % For each point, build matrix for its two equations
    currentA = [pts_wld(1,i) pts_wld(2,i) pts_wld(3,i) 1 0 0 0 0;
              0 0 0 0 pts_wld(1,i) pts_wld(2,i) pts_wld(3,i) 1];
    currentb = [pts_img(1,i);pts_img(2,i)];
    % Concatenate the equations to one matrix
    A(2*i-1:2*i,:) = currentA;
    b(2*i-1:2*i,:) = currentb;
end

%find pseudo-invers of A
rankA = rank(A);
[U,S,V] = svd(A);
%find S^-1
S_inv = eye(size(S))';
for i = 1:size(S,2) 
    if (S(i,i) == 0)
       S_inv(i,i) = 0;
    else
       S_inv(i,i) = 1/S(i,i);
    end
end
A_inv = V*S_inv*U';
%display('A*A_inv = '); A_inv*A;

p_8 = A_inv*b;
% Respape h to 3 by 3 homography matrix
P0_8 = reshape(p_8, 4, 2)';
P0 = [P0_8;0 0 0 1]; 
end

