function [ P ] = q2P( q )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
al_x = q(1);
al_y = q(2);
ang_x = q(3);
ang_y = q(4);
ang_z = q(5);
t_1 = q(6);
t_2 = q(7);

R = RotationMatrix([ang_x, ang_y, ang_z], 'eulerAngles');
P = [al_x 0 0;0 al_y 0;0 0 1]*[R(1,:) t_1;R(2,:) t_2; zeros(1,3) 1];
end

